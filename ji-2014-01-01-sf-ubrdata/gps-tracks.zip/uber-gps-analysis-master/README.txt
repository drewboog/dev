This will be a collection of analyses for the GPS drive data released by uber.
Right now we look at length of drives and overlap between the drives.

Input data (gpsdata/all.tsv) taken from from http://www.infochimps.com/datasets/uber-anonymized-gps-logs
For details about input data, see gpsdata/README.txt